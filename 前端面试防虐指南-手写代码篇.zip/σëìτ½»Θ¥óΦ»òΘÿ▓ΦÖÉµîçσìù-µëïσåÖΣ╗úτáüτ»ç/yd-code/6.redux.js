// store -> container
// currentState -> __value
// action -> f
// currentReducer -> map
// middleware -> IO functor

// console.log(typeof Symbol());
